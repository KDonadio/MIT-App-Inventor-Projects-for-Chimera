/* 
 * File:   myapp.h
 * Author: Keith Donadio
 *
 * Created on June 29, 2022, 4:56 PM
 */
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes

//------------------------------------------------------------------------------
// Function Prototypes
void __delay_uS(unsigned long int count);
void __delay_mS(unsigned short int ms );
//
void myAPP_Initialize(void);
void myAPP_Tasks(void);
void TC3_Ticker(TC_TIMER_STATUS status, uintptr_t context);
void BLESendTemperature(uint8_t temperature);
void BLESendData(uint8_t *data, uint8_t len);
float MCP9700_Temp_Celsius(void);

// EOF
